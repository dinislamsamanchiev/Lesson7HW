package com.company;

public class Medic extends Hero implements HavingSuperAbility{
    private int healPoints;

    public Medic(int healPoints) {
        this.healPoints = healPoints;
    }

    public int increase_experience(){

        int hh = healPoints * 10 / 100;
        return hh;
    }

    public int getHealPoints() {
        return healPoints;
    }

    public void setHealPoints(int healPoints) {
        this.healPoints = healPoints;
    }

    @Override
    public void applySuperAbility() {
        System.out.println( "Medic применил суперспособность CRITICAL DAMAGE");
    }
}
